<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Home::Vision</title>
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="slick/slick.css"/>
  	<link rel="stylesheet" type="text/css" href="slick/slick-theme.css"/>
	
</head>
<body>

<header class="top-header">
	<nav class="navbar navbar-expand-lg navbar-light bg-white">
	  <a class="navbar-brand" href="#">Logo</a>
	  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	    <span class="navbar-toggler-icon"></span>
	  </button>

	  <div class="collapse navbar-collapse" id="navbarSupportedContent">
	    <ul class="navbar-nav m-auto">
	      <li class="nav-item active">
	        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
	      </li>
	      <li class="nav-item">
	        <a class="nav-link" href="#">About us</a>
	      </li>
	      <li class="nav-item dropdown">
	        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
	          Servies
	        </a>
	        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
	          <a class="dropdown-item" href="#">Servies 1</a>
	          <a class="dropdown-item" href="#">Servies 2</a>
	          <div class="dropdown-divider"></div>
	          <a class="dropdown-item" href="#">Servies 3</a>
	        </div>
	      </li>
	      <li class="nav-item">
	        <a class="nav-link" href="#">Career</a>
	      </li>
	      <li class="nav-item">
	        <a class="nav-link" href="#">Contact us</a>
	      </li>
	      <li class="nav-item">
	        <a class="nav-link" href="#">Additional Information</a>
	      </li>
	    </ul>
	    <form class="form-inline my-2 my-lg-0">
	      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Sign In</button>
	    </form>
	  </div>
	</nav>
</header>
<section class="banner_slider">
	<div class="slider-background">
		<div>
		  	<img src="img/slider/slider01.jpg" alt="">
		</div>
		<div>
		  	<img src="img/slider/slider02.jpg" alt="">
		</div>		  		
	</div>
	<div class="register-form">
		<h2>Register Here</h2>
		<div class="register-form-data">
			<form action="" method="post">
				<div class="form-group">
					<input type="text" placeholder="Name" required="" class="form-control">
				</div>
				<div class="form-group">
					<input type="email" placeholder="Email" required="" class="form-control">
				</div>
				<div class="form-group">
					<input type="password" placeholder="Password" required="" class="form-control">
				</div>
				<div class="form-group mb-0">
					<input type="checkbox" required="" id="terms-and-condition">
					<label for="terms-and-condition"> I agree all terms and conditions</label>
				</div>
				<button class="btn btn-success" type="submit">Register</button>				
			</form>			
		</div>
	</div>
</section>
	<script type="text/javascript" src="//code.jquery.com/jquery-1.11.0.min.js"></script>
  <script type="text/javascript" src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
  <script type="text/javascript" src="slick/slick.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

  <script type="text/javascript">
    $(document).ready(function(){
      $('.slider-background').slick({
		dots: false,
		arrows: false,
		infinite: true,
		speed: 300,
		slidesToShow: 1,
		adaptiveHeight: true
      });
    });
  </script>
</body>
</html>